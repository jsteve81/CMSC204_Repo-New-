public class InvalidUserFormatException extends RuntimeException {
    public InvalidUserFormatException(String message) {
        super(message); // call to superclass
    }
}
