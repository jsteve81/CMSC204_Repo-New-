import java.util.*;
import java.io.*;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class PlaylistStudentTest {

	@BeforeAll
	static void setUpBeforeClass() throws Exception {
	}

	@AfterAll
	static void tearDownAfterClass() throws Exception {
	}

	@BeforeEach
	void setUp() throws Exception {
	}

	@AfterEach
	void tearDown() throws Exception {
	}

	// Testing every method and constructor
	
		/* For the sake of redundancy, I will not test any methods already covered in the public tests:
		 * (getCurrentSong, nextSong, previousSong) outside of possible edge cases.
		*/
	
	@Test
	void testNoArgConstructor() {
		Playlist myPlaylist = new Playlist();
		// brand-new playlist
		assertTrue(myPlaylist.isEmpty());
		assertEquals(0, myPlaylist.getSize());
		assertNull(myPlaylist.getName()); // everything set to empty, null, default from no-arg constructor
	}

	@Test
	void testConstructorWithArgs() {
		// playlist is not brand new and has information
		Playlist playlistTest = new Playlist("My Memories");

		assertEquals("My Memories", playlistTest.getName());
		assertNotEquals("my memories", playlistTest.getName()); // case-sensitive
		assertNotEquals("MY MEMORIES", playlistTest.getName());

		assertTrue(playlistTest.isEmpty());
	}
	
	@Test
	void testAddSong() {
		Playlist playlistTest = new Playlist("Test Playlist");
		Song testSong = new Song("Exit this Earth's Atomosphere", "Camellia");
		boolean resultTest = playlistTest.addSong(testSong);
		assertTrue(resultTest); // song was added successfully
	}
	
	@Test
	void testGetSize() {
		Playlist playlistTest = new Playlist("Test Playlist");
		playlistTest.addSong(new Song("Exit this Earth's Atomosphere", "Camellia"));
		playlistTest.addSong(new Song("Runaway", "Cascada"));
		
		assertEquals(2, playlistTest.getSize());
		// adding songs and tracking size
	}
	
	@Test
	void testIsEmpty() {
		Playlist playlistTest = new Playlist("Test Playlist");
		assertTrue(playlistTest.isEmpty());
		playlistTest.addSong(new Song("Exit this Earth's Atomosphere", "Camellia"));
		assertFalse(playlistTest.isEmpty());
		// tests whether playlist is empty or not
	}
	
	@Test
	void testGetSongs() {
		Playlist playlistTest = new Playlist("Test Playlist");
		
		Song testSong1 = new Song("Exit this Earth's Atomosphere", "Camellia");
		Song testSong2 = new Song("At The Speed of Light", "Dimrain47");
		Song testSong3 = new Song("Hexagon Force", "Waterflame");
		// creating 3 sample songs
		
		// adding to the playlist
		playlistTest.addSong(testSong1);
		playlistTest.addSong(testSong2);
		playlistTest.addSong(testSong3);
		
		GenericLinkedList<Song> songsTest = playlistTest.getSongs();
		assertEquals(3, songsTest.size());
		assertTrue(songsTest.contains(testSong1));
		assertTrue(songsTest.contains(testSong2));
		assertTrue(songsTest.contains(testSong3));
		// see if they are in the GenericLinkedList object
	}
	
	@Test
	void testGetName() {
		Playlist playlistTest = new Playlist("Studying for CMSC 204");
		assertEquals("Studying for CMSC 204", playlistTest.getName());
	}
	
	@Test
	void testRemoveSong() {
		Playlist playlistTest = new Playlist("Test Playlist");
		
		Song testSong1 = new Song("Fire Aura", "Kid2Will");
		Song testSong2 = new Song("At The Speed of Light", "Dimrain47");
		Song testSong3 = new Song("Every End", "Dimrain47");
		// creating 3 sample songs
		
		// adding to the playlist
		playlistTest.addSong(testSong1);
		playlistTest.addSong(testSong2);
		playlistTest.addSong(testSong3);

		boolean removed = playlistTest.removeSong(testSong1);
		assertTrue(removed);
		assertEquals(2, playlistTest.getSize()); // song was removed
	}
	
	// edge cases
	@Test
	void testRemoveSongFromEmpty() {
		Playlist playlistTest = new Playlist("Test");

		Song testSong1 = new Song("Fire Aura", "Kid2Will");
		Song testSong2 = new Song("At The Speed of Light", "Dimrain47");
		Song testSong3 = new Song("Promises", "Kabuki");
		// creating 3 sample songs

		// songs weren't added to the playlist and therefore don't exist.
		assertThrows(NoSuchElementException.class, () -> {playlistTest.removeSong(testSong3);});
	}
	
	@Test
	void testRemoveSongNotFound() {
		Playlist playlistTest = new Playlist("Test");

		Song testSong1 = new Song("Fire Aura", "Kid2Will");
		Song testSong2 = new Song("At The Speed of Light", "Dimrain47");
		Song testSong3 = new Song("Promises", "Kabuki");
		Song testSong4 = new Song("Minuet in G Major", "Mozart");
		// creating 4 sample songs
		
		// adding only 3 to the playlist
		playlistTest.addSong(testSong1);
		playlistTest.addSong(testSong2);				
		playlistTest.addSong(testSong3);
		
		boolean result = playlistTest.removeSong(testSong4);

		assertFalse(result); // the project does not require us to throw an FileNotFound or similar exception here
	}
}
