import java.util.*;
import java.io.*;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class SpotifyManagerStudentTest {

	@BeforeAll
	static void setUpBeforeClass() throws Exception {
	}

	@AfterAll
	static void tearDownAfterClass() throws Exception {
	}

	@BeforeEach
	void setUp() throws Exception {
	}

	@AfterEach
	void tearDown() throws Exception {
	}

	// Testing every method (no constructors in this class)
	
	/* For the sake of redundancy, I will not test any methods already covered in the public test:
	 * (testLoadUsersFromFile) outside of possible edge cases.
	 */
	
	@Test
	// Eclipse prompted me to throw multiple exceptions in the header
	void testFindUsers() throws Exception {
		// We try to find a sample user
		SpotifyManager managerTest = new SpotifyManager();

		FileWriter writerTest = new FileWriter("testUsers.txt"); // write them to the txt file
		writerTest.write("# USER\n");
		writerTest.write("username: Jonathan\n");
		writerTest.write("password: rockstar4859\n");
		writerTest.close(); // to avoid resource leak

		managerTest.loadUsersFromFile("testUsers.txt");

		User foundUser = managerTest.findUser("Jonathan", "rockstar4859");

		assertEquals("Jonathan", foundUser.getUsername());
		assertEquals("rockstar4859", foundUser.getPassword());
	}
	
	@Test
	void testGetUsers() throws Exception {
		SpotifyManager managerTest = new SpotifyManager();
		FileWriter writerTest = new FileWriter("testUsers.txt");
		writerTest.write("# USER\n");
		writerTest.write("username: Jonathan\n");
		writerTest.write("password: rockstar4859\n");

		writerTest.write("# USER\n");
		writerTest.write("username: Michael\n");
		writerTest.write("password: carrental999\n"); // 2 users registered
		writerTest.close();
		
		managerTest.loadUsersFromFile("testUsers.txt");

		User[] usersTest = managerTest.getUsers();

		assertEquals(2, usersTest.length);
		assertEquals("Jonathan", usersTest[0].getUsername());
		assertEquals("Michael", usersTest[1].getUsername()); // stored in an array, see first 2 
	}

	// edge cases 
	@Test
	void testFindUserInvalidPassword() throws Exception {
		SpotifyManager managerTest = new SpotifyManager();

		FileWriter writerTest = new FileWriter("testUsers.txt");
		writerTest.write("# USER\n");
		writerTest.write("username: Jonathan\n");
		writerTest.write("password: rockstar4859\n"); // creating a user and file
		writerTest.close();

		managerTest.loadUsersFromFile("testUsers.txt");

		assertThrows(InvalidPasswordException.class, () -> {
			managerTest.findUser("Jonathan", "rockstar9757"); // the password is wrong.
		});
	}
	
	@Test
	void testFindUserNotFound() throws Exception {
		SpotifyManager managerTest = new SpotifyManager();

		FileWriter writerTest = new FileWriter("testUsers.txt");
		writerTest.write("# USER\n");
		writerTest.write("username: Jonathan\n");
		writerTest.write("password: rockstar4859\n");
		writerTest.close();

		managerTest.loadUsersFromFile("testUsers.txt");

		assertThrows(UserNotFoundException.class, () -> {
			managerTest.findUser("Michael", "carrental999"); 
			// this user has not been created and cannot be found as a result
		});
	}
	
	@Test
	void testEmptyGetUsers() {
		SpotifyManager managerTest = new SpotifyManager();
		User[] usersTest = managerTest.getUsers();
		assertEquals(0, usersTest.length); // no users in the array
	}
	
	
	
	
}
