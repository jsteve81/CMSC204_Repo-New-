import java.util.*;
import java.io.*;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class GenericLinkedListStudentTest {

	@BeforeAll
	static void setUpBeforeClass() throws Exception {
	}

	@AfterAll
	static void tearDownAfterClass() throws Exception {
	}

	@BeforeEach
	void setUp() throws Exception {
	}

	@AfterEach
	void tearDown() throws Exception {
	}

	// Testing every method and constructor
	
	/* For the sake of redundancy, I will not test any methods already covered in the public test:
	 * (addFirst, addLast, clear, contains, iteratorhasnext, and iterator next) outside of possible edge cases.
	*/
	
	@Test
	void testNoArgConstructor() {
		GenericLinkedList<Integer> newlistTest = new GenericLinkedList<>();
		assertEquals(0, newlistTest.size()); // we just made a new object so size is 0 and is therefore empty
		assertTrue(newlistTest.isEmpty());
	}
	
	@Test
	void testConstructorWithArgs() {
		GenericLinkedList<Integer> oldlistTest = new GenericLinkedList<>(25);
		assertEquals(25, oldlistTest.size()); // this list has been pregenerated so it has elements and is not empty
		assertFalse(oldlistTest.isEmpty());
	}
	
	@Test
	void testRemoveWIndexArg() {
		GenericLinkedList<Integer> listTest = new GenericLinkedList<>();
		listTest.addLast(6);
		listTest.addLast(93);
		listTest.addLast(100);
		// adding sample integers to remove. We use add last because the new entry is sent to the bottom, not the top.

		int removedTest = listTest.remove(2);

		assertEquals(100, removedTest);
		assertEquals(2, listTest.size());
		assertFalse(listTest.contains(100));
	}
	
	// Multiple ways to remove from the list
	@Test
	void testRemoveFirst() {
		GenericLinkedList<String> listTest = new GenericLinkedList<>();
		listTest.addLast("One Direction");
		listTest.addLast("Video Game Soundtracks OST");
		listTest.addLast("Relaxing Beach Music");
		// adding sample integers to remove
		
		String removedValueTest = listTest.removeFirst(); // removing the first element added to the list

		assertEquals("One Direction", removedValueTest);
	}
	
	@Test
	void testRemoveLast() {
		GenericLinkedList<String> listTest = new GenericLinkedList<>();
		listTest.addLast("One Direction");
		listTest.addLast("Video Game Soundtracks OST");
		listTest.addLast("Relaxing Beach Music");
		// adding sample integers to remove
		
		String removedValueTest = listTest.removeLast(); // removing the first element added to the list

		assertNotEquals("One Direction", removedValueTest);
		assertEquals("Relaxing Beach Music", removedValueTest);

	}
	
	@Test
	void testRemoveWithTArg() {
		GenericLinkedList<String> listTest = new GenericLinkedList<>();

		listTest.addLast("One Direction");
		listTest.addLast("Video Game Soundtracks OST");
		listTest.addLast("Relaxing Beach Music");
		listTest.addLast("Bruno Mars");

		boolean removedValueTest = listTest.remove(String.valueOf("Relaxing Beach Music"));

		assertTrue(removedValueTest);
		assertFalse(listTest.contains("Relaxing Beach Music")); // this was removed
	}
	
	@Test
	void testGet() {
		GenericLinkedList<String> listTest = new GenericLinkedList<>();

		listTest.addLast("Rain Sounds");
		listTest.addLast("Coffee Shop Ambient Music");
		listTest.addLast("Future Funk");

		String resultTest = listTest.get(1);

		assertEquals("Coffee Shop Ambient Music", resultTest); // element at index 1
	}
	
	@Test
	void testIsEmpty() {
		GenericLinkedList<Integer> listTest = new GenericLinkedList<>();
		
		assertTrue(listTest.isEmpty()); // initially list was empty
		listTest.addLast(64); // something was added
		assertFalse(listTest.isEmpty()); // now the list isn't empty anymore.
	}
	
	@Test
	void testGetFirst() {
		GenericLinkedList<String> listTest = new GenericLinkedList<>();

		listTest.addLast("Vintage CD collection");
		listTest.addLast("Christmas Music");

		assertEquals("Vintage CD collection", listTest.getFirst()); // first in the list
	}
	
	@Test
	void testGetLast() {
		GenericLinkedList<String> listTest = new GenericLinkedList<>();

		listTest.addLast("Vintage CD collection");
		listTest.addLast("Christmas Music");

		assertEquals("Christmas Music", listTest.getLast()); // last in the list
	}
	
	@Test
	void testIteratorHasPrevious() {
		GenericLinkedList<String> listTest = new GenericLinkedList<>();

		listTest.addLast("Steel Drum SFX");
		listTest.addLast("Piano SFX");
		listTest.addLast("Classical Violin");

		ListIterator<String> userIterator = listTest.iterator();
		assertFalse(userIterator.hasPrevious());
		userIterator.next(); // move forward
		assertTrue(userIterator.hasPrevious()); // now that the iterator moved to next, previous exists
	}
	
	@Test
	void testIteratorPrevious() {
		GenericLinkedList<String> listTest = new GenericLinkedList<>();

		listTest.addLast("Piano SFX");
		listTest.addLast("Classical Violin");

		ListIterator<String> userIterator = listTest.iterator();	
		userIterator.next(); // move forward 2x
		userIterator.next();
		// the iterator is at the very end
		
		String previous = userIterator.previous();
		assertEquals("Classical Violin", previous); 

	}
	
	@Test
	void testIteratorRemove() {
		GenericLinkedList<String> listTest = new GenericLinkedList<>();

		listTest.addLast("Steel Drum SFX");
		listTest.addLast("Piano SFX");
		listTest.addLast("Classical Violin");

		ListIterator<String> userIterator = listTest.iterator();	
		userIterator.next(); // move to index 0
		userIterator.remove();
		
		assertEquals(2, listTest.size());
		assertFalse(listTest.contains("Steel Drum SFX")); // string at element index 0
	}
	
	@Test
	void testIteratorSize() {
		GenericLinkedList<Integer> listTest = new GenericLinkedList<>();

		listTest.addLast(17);
		listTest.addLast(40);
		listTest.addLast(365);
		listTest.addLast(24/7);

		ListIterator<Integer> userIterator = listTest.iterator();
		assertEquals(4, listTest.size());	
		// add to the list and check size
	}
	@Test
	void testtoArray() {
		GenericLinkedList<Integer> listTest = new GenericLinkedList<>();

		listTest.addLast(18);
		listTest.addLast(29/85);
		listTest.addLast(37 * 5); // we can even test operations too!

		Object[] arrayTest = listTest.toArray();

		// confirm array has correct properties
		assertEquals(3, arrayTest.length);
		assertEquals(18, arrayTest[0]);
		assertEquals(29/85, arrayTest[1]);
		assertEquals(37 * 5, arrayTest[2]);
	}
	
	// edge cases
	
	@Test
	void testEmptyNoSuchElementException() {
		GenericLinkedList<Integer> listTest = new GenericLinkedList<>();
		assertEquals(0, listTest.size());
		assertThrows(NoSuchElementException.class, () -> {listTest.removeFirst();});
		// because the list is empty, a NoSuchElementException is thrown
		
		assertNotEquals(-1, listTest.size());
	}
	
	@Test
	// necessary for the 4 filler methods I included for compilation.
	void testUnsupportedOperationException() {
		GenericLinkedList<Integer> listTest = new GenericLinkedList<>();

		ListIterator<Integer> userIterator = listTest.iterator();

		assertThrows(UnsupportedOperationException.class, () -> {userIterator.nextIndex();});
		assertThrows(UnsupportedOperationException.class, () -> {userIterator.previousIndex();});
		assertThrows(UnsupportedOperationException.class, () -> {userIterator.set(109);});
		assertThrows(UnsupportedOperationException.class, () -> {userIterator.add(5375);});
		// exceptions thrown for those methods
	}
	
	@Test
	void testRemoveInvalidOutofBoundsIndex() {
		GenericLinkedList<Integer> listTest = new GenericLinkedList<>();
		listTest.addLast(845);

		assertThrows(IndexOutOfBoundsException.class, () -> {listTest.remove(5);});
		// we can't remove index #5 if only 1 index exists.
	}


}
