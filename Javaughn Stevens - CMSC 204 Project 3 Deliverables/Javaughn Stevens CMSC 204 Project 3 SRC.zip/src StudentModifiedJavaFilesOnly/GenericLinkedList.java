import java.util.*; 
import java.io.*;
/* Name: Javaughn Stevens
 * Date: 3/7/26
 * Assignment: Project 3 Spotify Project CMSC 204
 * Term: Spring 2026
 * Instructor: Professor Gary Thai
 * Integrity Acknowledgement: This code is my original work, and 
 * I have not included source code from the Internet, AI generated nor from another student for this project.
 */

// Javadoc comments
/**
 * A generic doubly linked list implementation that stores elements in nodes.
 * This linked list supports insertion, removal, search, and iteration operations.
 * 
 * @param <T> type of elements stored in the linked list
 */

public class GenericLinkedList<T> implements Iterable<T> {
	private Node first; // node counterparts of T vars for linked implementation
	private Node last;
	private int size = 0; // empty variable seen in previous projects is redundant
	
	/**
     * Constructs an empty linked list object.
     */
	// No-arg constructor
	public GenericLinkedList() {
		size = 0;
	}
	
	/**
     * Constructs a linked list with an initial size value.
     *
     * @param size of the initial size value
     */
	// Constructor with args
	public GenericLinkedList(int size) {			
		this.size = size;	
	}
	
	/**
     * The Node class is nested in GenericLinkedList to represent elements in the linked list.
     * Each node stores data along with references to the next and
     * previous nodes if they exist.
     */
	// node class for LinkedList
		private class Node {
		    private T data;
		    private Node next;
		    private Node previous;
		    
		    /**
	         * Constructs a node containing the specified data.
	         *
	         * @param data the element to store in the node
	         */
		    private Node(T data) {
		        this.data = data;
		        this.next = null;
		        this.previous = null; // at the beginning, there is no next and no previous;
		    }
		}
	// we can apply concepts from ADT stacks, queues, and other similar data structures here
	
		/**
	     * Inserts an element at the front of the list.
	     *
	     * @param element the element the user wants to add
	     * @return the added element
	     */
		
	public T addFirst(T element) {
		Node newNode = new Node(element);

		if (isEmpty() == true) {
			first = newNode; // both head and tail point to new node
			last = newNode;
		} else {
			newNode.next = first; // next pointer points to current 1st node
			first.previous = newNode; // previous pointer points to new node
			first = newNode; // starts from head node
		}
		
		size++;
		return element;
	}
	
	/**
     * Inserts an element at the end of the list.
     *
     * @param element the element the user wants to add
	 * @return the added element
     */
	// For JUnit Public Tests
	public T addLast(T element) {
	    Node newNode = new Node(element);

	    if (isEmpty() == true) {     
	    	first = newNode; // both head and tail point to new node
			last = newNode;
	    } else {   
	        last.next = newNode; // next pointer points to new node
	        newNode.previous = last; // previous pointer points to current 1st node
	        last = newNode; // starts from tail node-
	    }

	    size++;
	    return element;
	}
	
	/**
     * Removes and returns the element at a specific index determined by the user.
     *
     * @param index of the element desired to be removed
     * @return the removed element
     * @throws NoSuchElementException if the list was empty
     * @throws IndexOutOfBoundsException if the index was invalid
     */	
	public T remove(int index) {
		if (isEmpty() == true) {
			throw new NoSuchElementException("The playlist is currently empty.");
		}
		
		if (index < 0 || index >= size) { // these are meant to not be accessible
			// index counts from 0 to size - 1.
	        throw new IndexOutOfBoundsException("Invalid index.");
		} 
		
		if (index == 0) { // this is basically the front
			T temp = removeFirst();
			return temp;
		}
		
		if (index == size - 1) { // this is basically the tail
			T temp = removeLast();
			return temp;
		}
		
		Node currentNode = first; // start at the head node

		for (int i = 0; i < index; i++) {
			currentNode = currentNode.next; // step through all of the nodes until the index is reached
		}

		// retain adjacent node values by assigning them to vars/objects.
		Node previous = currentNode.previous;
		Node next = currentNode.next;

		// skip over the current node when reconnecting the list.
		previous.next = next;
		next.previous = previous;

		size--; 
		

		return currentNode.data; // return removed value
	}
	
	 /**
     * Removes and returns the first element of the list.
     *
     * @return the removed element
     * @throws NoSuchElementException if the list was empty
     */
	public T removeFirst() {
		if (isEmpty() == true) {
			throw new NoSuchElementException("The playlist is currently empty.");
		}
		
		T data = first.data;
		first = first.next;
		if (first != null) { // if the linked list has at least 1 node with a value
			first.previous = null; // set previous pointer to null, indicating that this is now the head.
		} else {
			last = null; // list is empty.
		}

		size--;
		return data;
	}
	
	/**
     * Removes and returns the last element of the list.
     *
     * @return the removed element
     * @throws NoSuchElementException if the list was empty
     */
	public T removeLast() {
		if (isEmpty() == true) {
			throw new NoSuchElementException("The playlist is currently empty.");
		}
		
		T data = last.data;
		last = last.previous;
		if (last != null) { // if the linked list has at least 1 node with a value
			last.next = null; // set next pointer to null, indicating that this is now the tail.
		} else {
			first = null; // list is empty.
		}

		size--;
		return data;
	}
	
	/**
     * Removes the first occurrence of the specified element from the list.
     *
     * @param element the element desired to be removed
     * @return true if the element was found and removed, false if the element was not found
     * @throws NoSuchElementException if the list was empty
     */
	public boolean remove(T element) {
		if (isEmpty() == true) {
			throw new NoSuchElementException("The playlist is currently empty");
		}
		Node currentNode = first; // start at the head node;
		
		while (currentNode != null) {
			if (currentNode.data.equals(element) == true) {
				if (currentNode == first) {
					T temp = removeFirst(); // calls to preexisting methods to reuse existing code
				}
				else if (currentNode == last) {
					T temp = removeLast();
				}
				else {
					// retain adjacent node values by assigning them to vars/objects.
					Node previous = currentNode.previous;
					Node next = currentNode.next;

					// skip over the current node when reconnecting the list.
					previous.next = next;
					next.previous = previous;
					size--;
				}
				return true;  // if the specified element is found, return true
			}
			currentNode = currentNode.next; // one giant loop through all the nodes.
		}
		return false; // if the specified element is not found, return false
	}
	
	/**
     * Determines whether the list currently contains a specific element determined by the user
     *
     * @param element the desired element to search for
     * @return true if the element exists in the list, false if it doesn't exist
     */
	public boolean contains (T element) {
		if (isEmpty() == true) {
			return false; // must return false if nothing exists
		}
		
		Node steppingNode = first; // start at the head of the linked list

		while (steppingNode != null) { // while the nodes have values
			if (steppingNode.data.equals(element)) {
				return true; // if the node data matches the element, the element is found and returns true
			} 
			steppingNode = steppingNode.next; // assign the next node data to currentNode
		}

		return false; // if data from all nodes doesn't match the element at least once, return false
	}
	
	/**
     * Returns the element at the specified index without removing it.
     *
     * @param index the index of the desired element
     * @return the element at the determined index
     * @throws NoSuchElementException if the list was empty
     * @throws IndexOutOfBoundsException if the index was invalid
     */
	public T get (int index) {
		if (isEmpty() == true) {
			throw new NoSuchElementException("The playlist is currently empty");
		}
		
		if (index < 0 || index >= size) { // these are meant to not be accessible
			// index counts from 0 to size - 1.
	        throw new IndexOutOfBoundsException("Invalid index.");
		} 
		
		Node indexedNode = first; // start at the head node
		
		for (int i = 0; i < index; i++) {
			indexedNode = indexedNode.next; // step through every node until we reach the node at the index
		}
		
/* We must step through nodes this way because we can't directly interact with nodes of a specific
index like we can with array-based implementation. Instead of stepping through every element, we 
step to every element up to the index. */
		
		return indexedNode.data;
	}
	
	/**
     * Checks whether the list is empty or not.
     *
     * @return true if the list was empty, false if it isn't
     */
	// getter methods
	public boolean isEmpty() {
		if (size == 0) {
			return true;
		} else {
			return false;
		}
	}
	
	 /**
     * Returns the first element in the list without removing it.
     *
     * @return the first element
     * @throws NoSuchElementException if the list was empty
     */
	public T getFirst() {
		if (isEmpty() == true) {
			throw new NoSuchElementException("The playlist is currently empty");
		}
		
		return first.data;
	}
	 /**
     * Returns the last element in the list without removing it
     *
     * @return the last element
     * @throws NoSuchElementException if the list was empty
     */
	public T getLast() {
		if (isEmpty() == true) {
			throw new NoSuchElementException("The playlist is currently empty");
		}
		
		return last.data;
	}
	
	/**
     * Removes all elements from the list.
     */
	// For JUnit Public Tests 
	public void clear() {
		first = null;
		last = null;
		size = 0;
		
		// reset everything, similar to a no-arg constructor
	}
	
	/**
	 * An iterator implementation that allows the traversal of the linked list
	 * both forwards and backwards
	 * 
	 * This iterator follows the behavior defined by the ListIterator interface
	 * and provides methods to move through the list and remove elements
	 * during the iteration process
	 */
	// nested classes
	private class GenericIterator implements ListIterator<T> {
		private Node currentNode = first; // starting at head method.
		private Node lastReturn = null; // for returning to methods
		
		/**
		 * Determines whether or not there is another element after the current iterator position.
		 *
		 * @return true if another element exists, false if it doesn't
		 */
		public boolean hasNext() {
			if (currentNode == null) {
				return false; // if null, it means that there is no node after
			} else {
				return true;
			}
		}
		
		/**
		 * Returns the next element in the iteration and advances the iterator forwards as it traverses.
		 *
		 * @return the next element in the list
		 * @throws NoSuchElementException if the next element is null or nonexistent
		 */
		public T next() {
			if (hasNext() == false) {
				throw new NoSuchElementException("There is no next element.");
			}
			
			lastReturn = currentNode; // assign current to temporary variable for returning before updating.
			currentNode = currentNode.next;

			return lastReturn.data;
		}
		
		
		/**
		 * Determines whether there is an element before the current iterator position as it traverses.
		 *
		 * @return true if a previous element exists, false if the previous element is null or nonexistent.
		 */
		public boolean hasPrevious() {
			if (isEmpty() == true) {
				return false; // if empty, there is no previous
			}
			
			if (currentNode == null) {
				if (last != null) { // if the tail is not null, there is a previous
					return true;
				} else {
					return false;
				}
			}
			
			if (currentNode.previous != null) { // if the previous is also not null, there is a previous
				return true;
			} else {
				return false;
			}
		}
		
		/**
		 * Returns the previous element in the iteration and advances the iterator backward as it traverses.
		 *
		 * @return the previous element in the list
		 * @throws NoSuchElementException if no previous element doesn't exist
		 */
		public T previous() {
			if (hasPrevious() == false) {
				throw new NoSuchElementException("There is no previous element.");
			}
			
			if (currentNode == null) {
				currentNode = last; // this is the last node
			} else {
				currentNode = currentNode.previous; // there is a node before it
			}
			
			lastReturn = currentNode; // similar to next(), we must use another variable for returning.
			return lastReturn.data;
			
		}	
		
		/**
		 * Removes the last element returned by either next() or previous().
		 *
		 * @throws IllegalStateException if neither next() or previous() has been called beforehand
		 *         or if remove() has already been called after the last iteration step
		 */
		public void remove() {
			if (lastReturn == null) {
				throw new IllegalStateException("There is nothing to remove.");
			}
			// retain adjacent node values by assigning them to vars/objects.
			Node previous = lastReturn.previous; 
			Node next = lastReturn.next;

			if (previous != null) {
				previous.next = next; // if previous has a value, assign to remove a intermediate or end node
			}
			else
			{
				first = next;
			}
			if (next != null) { // reconnect link
				next.previous = previous;
			} else {
				last = previous;
			}
			
			size--;

			lastReturn = null; // set to null for accuracy if called multiple times. 
		}

		// Interface methods necessary for compilation
		/**
		 * Interface methods
		 *
		 * @throws UnsupportedOperationException
		 */
		@Override
		public int nextIndex() {
			throw new UnsupportedOperationException(); 
			// filler because I have already implemented the required methods as outlined in project description
		}
		/**
		 * Interface methods
		 *
		 * @throws UnsupportedOperationException
		 */
		@Override
		public int previousIndex() {
			throw new UnsupportedOperationException();
			// filler because I have already implemented the required methods as outlined in project description
		}
		/**
		 * Interface methods
		 *
		 * @throws UnsupportedOperationException
		 */
		@Override
		public void set(T element) {
			throw new UnsupportedOperationException();
			// filler because I have already implemented the required methods as outlined in project description
		}
		/**
		 * Interface methods
		 *
		 * @throws UnsupportedOperationException
		 */
		@Override
		public void add(T element) {
			throw new UnsupportedOperationException();
			// filler because I have already implemented the required methods as outlined in project description

		}
		
		/**
		 * Returns the number of elements currently stored in the linked list.
		 *
		 * @return the size of the list
		 */
		// helper method
		public int size() {
			return size;
		}
		
	}
	/**
     * Returns an iterator for traversing the linked list.
     *
     * @return a ListIterator for this list
     */
	@Override
	public ListIterator<T> iterator() {
		return new GenericIterator(); // return new object;
	}
	
	/**
     * Converts the linked list into an array.
     *
     * @return an array containing all elements in the list
     */	
	public Object[] toArray() {
		Object[] linkedArray = new Object[size]; // display nodes in an array
		Node node = first; // start at the head node
		
		for (int i = 0; i < size; i++) { // step through the array
			linkedArray[i] = node.data;
			node = node.next;
		}
		return linkedArray;
	}
	
	/**
	 * Returns the number of elements in the linked list.
	 *
	 * @return the total number of elements in the list
	 */
	public int size() {
		return size;
	}
	    
	}
	
