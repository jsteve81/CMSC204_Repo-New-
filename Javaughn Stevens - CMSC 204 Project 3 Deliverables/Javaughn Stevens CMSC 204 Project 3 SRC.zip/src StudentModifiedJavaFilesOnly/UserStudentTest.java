import java.util.*;
import java.io.*;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class UserStudentTest {

	@BeforeAll
	static void setUpBeforeClass() throws Exception {
	}

	@AfterAll
	static void tearDownAfterClass() throws Exception {
	}

	@BeforeEach
	void setUp() throws Exception {
	}

	@AfterEach
	void tearDown() throws Exception {
	}
	
	// Testing every method and constructors

	@Test
	void testNoArgConstructor() {
		User userTest = new User();

		assertEquals(0, userTest.getPlaylistCount());
		assertNull(userTest.getUsername());
		assertNull(userTest.getPassword());
		assertNotNull(userTest.getPlaylists()); // once again, no values anywhere
	}

	@Test
	void testConstructorWithArgs1() {
		User userTest = new User("Jonathan", "spacecowboys27485");

		assertEquals("Jonathan", userTest.getUsername());
		assertEquals("spacecowboys27485", userTest.getPassword());
		assertEquals(0, userTest.getPlaylistCount()); // no created playlists with this constructor
		assertNotNull(userTest.getPlaylists());
	}
	
	@Test
	void testConstructorWithArgs2() {
		User userTest = new User(16, "Jonathan", "spacecowboys27485");

		assertEquals("Jonathan", userTest.getUsername());
		assertEquals("spacecowboys27485", userTest.getPassword());
		assertEquals(16, userTest.getPlaylistCount()); // with 3 args, the user can have precreated playlists.
		assertNotNull(userTest.getPlaylists());
	}

	@Test
	void addPlaylist() {
		User userTest = new User("Jonathan", "spacecowboys27485");
		Playlist playlistTest = new Playlist("Western Classics");

		userTest.addPlaylist(playlistTest); // testing basic addition of a playlist
		assertEquals(1, userTest.getPlaylistCount());
		assertEquals(1, userTest.getPlaylists().size());
	}
	
	@Test
	void getPlaylistCount() {
		User userTest = new User("Jonathan", "spacecowboys27485");
		userTest.addPlaylist(new Playlist("Pirate Music"));
		userTest.addPlaylist(new Playlist("Space Music"));
		userTest.addPlaylist(new Playlist("Sleeping Music"));

		assertEquals(3, userTest.getPlaylistCount()); // we added 3 playlists
	}
	
	@Test
	void removePlaylist() {
		User userTest = new User("Jonathan", "spacecowboys27485");
		Playlist playlistTest = new Playlist("Test Playlist #1");

		userTest.addPlaylist(playlistTest);
		userTest.removePlaylist(playlistTest);
		assertEquals(0, userTest.getPlaylistCount()); // 1 - 1 = 0;
	}
	
	@Test
	void testEmptyCollection() {
		User userTest = new User("Jonathan", "spacecowboys27485");
		assertTrue(userTest.emptyCollection()); // no playlists -> collection is empty
		userTest.addPlaylist(new Playlist("Test"));
		assertFalse(userTest.emptyCollection()); // a playlist was added - collection is not empty anymore
	}
	
	// testing setter & getter methods
	@Test
	void testGetUsername() {
		User userTest = new User("Richard", "bananamonkey746");
		assertEquals("Richard", userTest.getUsername());
		assertNotEquals("bananamonkey746", userTest.getUsername());

	}
	
	@Test
	void testGetPassword() {
		User userTest = new User("Richard", "bananamonkey746");
		assertNotEquals("Richard", userTest.getPassword());
		assertEquals("bananamonkey746", userTest.getPassword());
	}
	
	@Test
	void testGenericLinkedList() {
		User userTest = new User("Jonathan", "spacecowboys27485");
		userTest.addPlaylist(new Playlist("Pirate Music"));
		userTest.addPlaylist(new Playlist("Space Music"));
		userTest.addPlaylist(new Playlist("Sleeping Music"));

		assertEquals(3, userTest.getPlaylists().size()); // method is called differently here
	}
	
	@Test
	void testSetPassword() {
		User userTest = new User("Jonathan", "spacecowboys27485");
		userTest.setPassword("programmerz");
		assertEquals("programmerz", userTest.getPassword());
	}
	
	// edge cases - None for this particular class	
	
}
