import java.util.*; 
import java.io.*;

// Javadoc comments
/**
 * The Playlist class represents a collection of Song objects stored in a
 * GenericLinkedList. It provides functionality for adding and removing
 * songs, navigating through different songs, and retrieving info about a playlist.
 * 
 * The playlist maintains an iterator that allows traversal forward and
 * backward through the list of songs.
 */
public class Playlist {
	private String name;
	private GenericLinkedList<Song> userSongs;
	private ListIterator<Song> userIterator;
	private Song currentSong;
	// empty and size are unnecessary because GenericLinkedList tracks size
	
	// No-arg constructor
	/**
	 * Constructs an empty, unnamed playlist.
	 * Initializes the song linked list and iterator.
	 */
	public Playlist() {
		name = null;
		userSongs = new GenericLinkedList<>(); // creating GenericLinkedList and userIterator objects
		userIterator = userSongs.iterator();
		currentSong = null;
	}
	
	// Constructor with args
	/**
	 * Constructs a playlist with a specified name determined by the user.
	 *
	 * @param name the name assigned to the playlist
	 */
	// Constructor with args
	public Playlist (String name) {
		this.name = name;
		userSongs = new GenericLinkedList<>(); 
		userIterator = userSongs.iterator();
		currentSong = null; // song isn't already playing by default
		
		// only name uses this. statement
	}

	/**
	 * Adds a song to the end of the playlist.
	 * If this is the first song added, it becomes the current song.
	 *
	 * @param song the song to be added to the playlist determined by the user
	 * @return true once the song has been successfully added
	 */
	public boolean addSong(Song song) {
		userSongs.addLast(song); // add new song to the end of the playlist
		
		if (currentSong == null) {
			currentSong = song; // this is where we play the 1st song.
		}
        userIterator = userSongs.iterator(); // reset iterator after each addition to playlist

        return true;
	}
	
	/**
	 * Returns the current song in the playlist.
	 *
	 * @return the currently selected song
	 * @throws NoSuchElementException if the playlist is currently empty
	 */
	// getter methods
	public Song getCurrentSong() {
		if (isEmpty() == true) {
			throw new NoSuchElementException("The playlist is currently empty.");
		}
		
		return currentSong;
	}
	
	/**
	 * Returns the number of songs currently in the playlist.
	 *
	 * @return the total number of songs in the playlist
	 */
	public int getSize() {
		int size = userSongs.size();
		return size;
	}
	
	/**
	 * Determines whether or not the playlist contains any songs currently.
	 *
	 * @return true if the playlist was empty, false if it was not.
	 */
	public boolean isEmpty() {
		if (userSongs.size() == 0) {
			return true;
		} else {
			return false;
		}
	}
	
	/**
	 * Returns the list of songs currently contained in the playlist.
	 *
	 * @return the GenericLinkedList storing the playlist songs
	 */
	public GenericLinkedList<Song> getSongs() {
		return userSongs;
	}
	
	// Helper method
	/**
	 * Returns the current name of the playlist.
	 *
	 * @return the playlist name
	 */
	public String getName() {
		return name;
	}
	
	/**
	 * Advances to the next song in the playlist and returns it.
	 *
	 * @return the next song in the playlist, or null if there is no next song after the current one.
	 * @throws NoSuchElementException if the playlist was empty
	 */
	public Song nextSong() {
		if (isEmpty() == true) {
			throw new NoSuchElementException("The playlist is currently empty.");
		}
		
		if (userIterator.hasNext() == true) { // if there is a next song to play, we assign it to currentSong
            currentSong = userIterator.next(); // done similarly to how nodes were used in GenericLinkedList.java
            return currentSong;
        } else {
        	return null; // if there is no next song, we return null
        }
	}
	
	/**
	 * Advances to the previous song in the playlist and returns it.
	 *
	 * @return the previous song in the playlist, or null if there is no previous song after the current one.
	 * @throws NoSuchElementException if the playlist was empty
	 */
	public Song previousSong() {
		if (isEmpty() == true) {
			throw new NoSuchElementException("The playlist is currently empty.");
		}
		
		if (userIterator.hasPrevious() == true) { // if there is a previous song to play, we assign it to currentSong
            currentSong = userIterator.previous(); 
            return currentSong;
        } else {
        	return null; // if there is no previous song, we return null
        }
	}
	
	/**
	 * Removes a specific song from the playlist determined by the user.
	 *
	 * @param song the song desired to be removed
	 * @return true if the song was successfully removed, false if the song was not found
	 * @throws NoSuchElementException if the playlist was empty
	 */
	public boolean removeSong(Song song) {
		if (isEmpty() == true) {
			throw new NoSuchElementException("The playlist is currently empty.");
		}
		
		if (userSongs.remove(song) == true) { // we return true or false based on if there is a song to remove.
			return true;
		} else {
			return false;
		}
	}
}
