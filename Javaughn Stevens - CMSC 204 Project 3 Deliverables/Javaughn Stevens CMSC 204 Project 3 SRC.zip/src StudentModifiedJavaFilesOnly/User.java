import java.util.*; 
import java.io.*;

// Javadoc comments
/**
 * The User class represents a user in the playlist system.
 * Each user has a username, password, and a collection of playlists.
 * Playlists are stored in a GenericLinkedList structure.
 * 
 * The class provides methods for adding playlists, removing playlists,
 * and accessing user account information.
 */
public class User {
	private int playlistCount = 0;
	private String username;
	private String password;
	private GenericLinkedList<Playlist> userPlaylists;
	
	/**
	 * Constructs a user object with no username or password.
	 * Initializes an empty playlist collection.
	 */
	// No-arg constructor
	public User() {
		playlistCount = 0;
		username = null;
		password = null;
		userPlaylists = new GenericLinkedList<>();
	}
	
	// Constructors with args
	/**
	 * Constructs a user with a specified username and password.
	 * Also initializes an empty playlist collection.
	 *
	 * @param username the current username of the user
	 * @param password the current password of the user
	 */
	// 2-arg constructor necessary for JUnit Public Tests
	public User(String username, String password) {
		this.username = username;
		this.password = password;
		userPlaylists = new GenericLinkedList<>();
	}

	/**
	 * Constructs a user with a specified playlist count, username, and password.
	 *
	 * @param playlistCount the number of playlists currently owned by the user
	 * @param username the current username of the user
	 * @param password the current password of the user
	 */
	// 3-arg constructor
	public User(int playlistCount, String username, String password) {
		this.playlistCount = playlistCount;
		this.username = username;
		this.password = password;
		userPlaylists = new GenericLinkedList<>();

	}
	
	/**
	 * Adds a new playlist to the user's current collection.
	 * Increases the playlist count.
	 *
	 * @param playlist the playlist to be added
	 */
	public void addPlaylist(Playlist playlist) {
		userPlaylists.addLast(playlist);
		playlistCount++;
	}
	 
	// Getter method
	/**
	 * Returns the number of playlists currently owned by the user.
	 *
	 * @return the total number of playlists
	 */
	public int getPlaylistCount() {
		return playlistCount;
	}

	// Helper methods for consistency 

	/**
	 * Removes a playlist from the user's current collection.
	 * Decreases the playlist count.
	 *
	 * @param playlist the playlist to be removed
	 */
	// Helper methods for consistency (may be wrong)
	public void removePlaylist(Playlist playlist) {
		playlistCount--;
	}
	
	/**
	 * Determines whether the user currently has any playlists.
	 *
	 * @return true if the playlist collection was empty, false if it was not
	 */
	public boolean emptyCollection() {
		if (playlistCount == 0) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * Returns the current username of the user.
	 *
	 * @return the user's username
	 */

	// Helper methods for public JUnit testing
	public String getUsername() {
		return username;
	}
	
	/**
	 * Returns the current password of the user.
	 *
	 * @return the user's password
	 */
	public String getPassword() {
		return password;
	}

	/**
	 * Returns the collection of playlists currently owned by the user.
	 *
	 * @return a GenericLinkedList containing the user's current playlists
	 */
	public GenericLinkedList<Playlist> getPlaylists() {
        return userPlaylists;
    }

	/**
	 * Sets the user's password.
	 *
	 * @param password2 the new password to assign to the user
	 */
	public void setPassword(String password2) {
		this.password = password2; // necessary change for passing JUnit public tests
	}
	
	
}
