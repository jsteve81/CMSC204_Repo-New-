public class UserNotFoundException extends Exception {
    public UserNotFoundException(String message) {
        super(message); // call to superclass
    }
}
