import java.util.*; 
import java.io.*;

// Javadoc comments
/**
 * The SpotifyManager class manages all users in the current system.
 * 
 * The class does all of the following:
 * - Loading current users, playlists, and songs from a .txt file
 * - Searching for users based on username and password
 * - Returning all users stored in the current system
 * 
 * Users are stored inside a GenericLinkedList object.
 */
public class SpotifyManager {
	private GenericLinkedList<User> usersList = new GenericLinkedList<>();
	
	/**
	 * Loads user data from a file and populates the system.
	 * The file may contain current users, their playlists, and songs.
	 *
	 * @param filename the name of the file to read from
	 * @throws IOException if the file cannot be read
	 * @throws InvalidUserFormatException if the file format is incorrect from what is valid
	 */
	public void loadUsersFromFile(String filename) throws IOException, InvalidUserFormatException {
		BufferedReader userReader = new BufferedReader( new FileReader(filename)); // buffered reader for JUnit test
        String line; // recording each output
        User currentUser = null;
        Playlist currentPlaylist = null;

        while ((line = userReader.readLine()) != null) {
            line = line.trim(); // for JUnit
            if (line.equals("# USER") == true) {
                currentUser = null; // everything starts out being null
                currentPlaylist = null;
            }
            else if (line.startsWith("username:") == true) {
                String username = line.substring(9).trim(); // username tracked after 9th character
                currentUser = new User(username, null);
            }
            else if (line.startsWith("password:") == true) {
                String password = line.substring(9).trim(); // password tracked after 9th character
           
                if (currentUser == null) {
                    throw new InvalidUserFormatException("User format is invalid.");
                }
                    
                currentUser.setPassword(password); // we set the password
                usersList.addLast(currentUser); // user is added to the list
            }

            else if (line.startsWith("playlist:") == true) { // playlist 
                String playlistName = line.substring(9).trim(); 
                currentPlaylist = new Playlist(playlistName);
                if (currentUser != null) {
                    currentUser.addPlaylist(currentPlaylist); // if user is real, they can add playlists
                }
            }

            else if (line.startsWith("song:") == true) { // song
                String songData = line.substring(5).trim();
                String[] songParts = songData.split("-");

                if (songParts.length != 2) { // array must have 2 elements: Name and artist
                    throw new InvalidUserFormatException("User format is invalid.");
                }

                String songTitle = songParts[0].trim(); // trim first and second elements of the song data.
                String songArtist = songParts[1].trim();

                Song song = new Song(songTitle, songArtist);

                if (currentPlaylist != null) {
                    currentPlaylist.addSong(song);
                }
            }
        }

        userReader.close(); // to avoid resource leak
	}
	
	/**
	 * Searches for a user with the specified username and password.
	 *
	 * @param username the username to search for
	 * @param password the password to search for
	 * @return the matching User object
	 * @throws UserNotFoundException if the username does not exist or is incorrect
	 * @throws InvalidPasswordException if the password does not exist or is incorrect
	 * @throws InvalidUserFormatException if user data is invalid
	 */
	public User findUser(String username, String password) throws UserNotFoundException, InvalidUserFormatException {
		   ListIterator<User> userIterator = usersList.iterator(); // find user using iterator
	       while (userIterator.hasNext() == true) {
	       User user = userIterator.next();
	            if (user.getUsername().equals(username) == true) {
	                if (user.getPassword().equals(password) == false) {
	                    throw new InvalidPasswordException("Password is invalid.");
	                }
	                return user; // only return if username and password match and are valid
	            }
	       }   
	       throw new UserNotFoundException("User cannot be found.");
	}

	/**
	 * Returns all users currently stored in the system as an array.
	 *
	 * @return an array containing all User objects
	 */
	public User[] getUsers() {
		int size = usersList.size();
		User[] userArray = new User[size]; // declare new array

        ListIterator<User> userIterator = usersList.iterator();
        int i = 0;

        while (userIterator.hasNext() == true) { // stepping through nodes
            userArray[i++] = userIterator.next();
        }

        return userArray;
	}

}
