import java.util.*; 
import java.io.*;

// Javadoc comments
/**
 * The Song class represents a single song in the playlist.
 * Each song contains a song title and an artist name.
 * 
 * This class provides methods for accessing and modifying song
 * information, comparing songs, and generating a string representation
 * of a specific song.
 */
public class Song {
	private String songName;
	private String artistName;
	
	// No-arg constructor
	/**
	 * Constructs an empty Song object with no defined title or artist.
	 */
	public Song() {
		songName = null;
		artistName = null;
	}
	
	/**
	 * Constructs a Song with a specified title and artist determined by the user.
	 *
	 * @param songName the title of the song
	 * @param artistName the name of the artist
	 */
	// Constructor with args
	public Song(String songName, String artistName) {
		this.songName = songName;
		this.artistName = artistName;
	}
	
	
	// Setters & Getters
	/**
	 * Sets the title of the song.
	 *
	 * @param songName the title for the song
	 */
	public void setSongName(String songName) {
		this.songName = songName;
	}
	
	/**
	 * Returns the title of the song.
	 *
	 * @return the the title for the song
	 */
	public String getSongName() {
		return songName;
	}
	
	/**
	 * Sets the artist name for the song.
	 *
	 * @param artistName the artist name
	 */
	public void setArtistName(String artistName) {
		this.artistName = artistName;
	}
	 
	/**
	 * Returns the artist name for the song.
	 *
	 * @return the artist name
	 */
	// specific name for other public JUnit tests
	public String getArtist() {
		return artistName;
	}
	
	// Helper methods
	/**
	 * Compares this song with another object to determine if they are equal.
	 * Two songs are considered equal if both the song name and artist name are a match.
	 *
	 * @param object the object to compare with this song
	 * @return true if the songs are a match, false if they aren't
	 */
	public boolean equals(Object object) {
       if (this == object) {
    	   return true;
       }
       
       if ((object instanceof Song) == false) { // if object doesn't reference Song or a class related to Song
           return false;
       }
		
       Song object2 = (Song) object;
       
        if (songName.equals(object2.songName) && artistName.equals(object2.artistName)) {
        	return true;
        } else {
        	return false;
        }
	}
	
	/**
	 * Returns a string representation of the song and the artist.
	 * The format is "songName - artistName".
	 *
	 * @return a formatted string describing the song and the artist
	 */
    public String toString() {
        return (songName + " - " + artistName);
    }

    /**
	 * Returns the title of the song.
	 * This method is used by certain tests that expect a getTitle method.
	 * It's identical in function to getSongName().
	 *
	 * @return the song title
	 */
    // Helper method
	public Object getTitle() {
		return songName;
	}


	
	
}
