import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class SongStudentTest {

	@BeforeAll
	static void setUpBeforeClass() throws Exception {
	}

	@AfterAll
	static void tearDownAfterClass() throws Exception {
	}

	@BeforeEach
	void setUp() throws Exception {
	}

	@AfterEach
	void tearDown() throws Exception {
	}

	// Testing every method and constructor
	
	// Since there are no public test cases, I will test every method + edge cases
	@Test
	void testNoArgConstructor() {
		Song songTest = new Song();

		assertNull(songTest.getSongName());
		assertNull(songTest.getArtist()); // nothing has any value from no-arg constructor
	}
	
	@Test
	void testConstructorWithArgs() {
		Song songTest = new Song("I Wanna Dance With Somebody", "Whitney Houston");
		
		assertEquals("I Wanna Dance With Somebody", songTest.getSongName());
		assertEquals("Whitney Houston", songTest.getArtist()); // the fields have values from the parameter args
	}
	
	@Test
	void testSetSongName() {
		Song songTest = new Song();
		songTest.setSongName("Crystals In The Air"); // setting a name
	}
	
	@Test
	void testGetSongName() {
		Song songTest = new Song();
		songTest.setSongName("Crystals In The Air");
		assertEquals("Crystals In The Air", songTest.getSongName()); // testing retrieval of the name
		
	}
	
	// same thing for artist setter & getter
	@Test
	void testSetArtistName() {
		Song songTest = new Song();
		songTest.setArtistName("Delilah");
	}
	
	@Test
	void testGetArtistName() {
		Song songTest = new Song();
		songTest.setArtistName("Delilah");
		assertEquals("Delilah", songTest.getArtist());
	}
	
	@Test
	void testToString() {
		Song songTest = new Song("If I Could Turn Back Time", "Chel");
		String resultTest = songTest.toString();
		assertEquals("If I Could Turn Back Time - Chel", resultTest); // toString returns String
	}
	
	@Test
	void testEquals() {
		Song songTest1 = new Song("Fire Aura", "Kid2Will");
		Song songTest2 = new Song("Fire Aura", "Kid2Will");
		Song songTest3 = new Song("Sky Aura", "Kid2Will");

		assertTrue(songTest1.equals(songTest2)); // these are the same
		assertFalse(songTest1.equals(songTest3)); // these are not
	}
	
	@Test
	void testGetTitle() { // same as GetSongName but named differently for public JUnit tests
		Song songTest1 = new Song("Lightning Aura", "Kid2Will");
		assertEquals("Lightning Aura", songTest1.getTitle()); // retrieve title, not artist
		assertNotEquals("Kid2Will", songTest1.getTitle());

	}
	
	// edge cases
	
	@Test
	void testEqualsDifferentObjectType() {
		Song songTest1 = new Song("Cream of Mushroom Soup", "Campbell"); // this is not a song, it is a brand of soup

		assertFalse(songTest1.equals("This is not a song.")); // tests instanceof check
	}
	
}
