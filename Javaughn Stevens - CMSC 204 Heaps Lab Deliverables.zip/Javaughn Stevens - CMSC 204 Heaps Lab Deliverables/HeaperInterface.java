// This is an small interface I made to supplement my learning. 

public interface HeaperInterface {

	/** Insert a new value into the heap */
    void insert(int value);

    /** Remove and return the root of the heap (max or min depending on the type of heap) */
    int delete();

    /** Return the root of the heap without removing it. */
    int peek();

    /** Return the number of elements in the heap. */
    int size();

    /** Check if the heap is empty. */
    boolean isEmpty();

    /** Return the max node of the heap */
    int max();
    
    /** Return the minimum node of the heap */
    int min();
}
