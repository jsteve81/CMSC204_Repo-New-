// import statements
import java.util.*;
import java.io.*;

public class Heaper {
	
	public static void heapify (int[] heapArray, int length, int i) {
		int maxNode = i; // assume current index is i until we compare it with children
        int leftChild = 2 * i + 1; // child nodes use formula from Pearson video
        int rightChild = 2 * i + 2;

        // if left child exists, and it is greater than the current max node, reassign
        if ((leftChild < length) && (heapArray[leftChild] > heapArray[maxNode])) {
            maxNode = leftChild;
        }
        // same thing for right child
        if ((rightChild < length) && (heapArray[rightChild] > heapArray[maxNode])) {
            maxNode = rightChild;
        }
        // if the parent node is not the max node, swap the indexes
        if (maxNode != i) {
            int temporary = heapArray[i];
            heapArray[i] = heapArray[maxNode];
            heapArray[maxNode] = temporary; // process of swapping parent nodes with children

            heapify(heapArray, length, maxNode); // recursion until heapify process is done.
        }
	}
	
	/* Recursion is useful for this implementation because heaping is a process that has a base case,
	 * namely, when the heap is a minheap, maxheap, or sorted. */
	
	public static void heaperSorter(int[] heapArray) {
        int length = heapArray.length;

        // build heap max
        for (int i = length / 2 - 1; i >= 0; i--) {
        	// we go down the tree from the root to the bottom using recursion
            heapify(heapArray, length, i);
        }

        // swap root with last element
        for (int i = length - 1; i >= 0; i--) {
            int temporary = heapArray[0];
            heapArray[0] = heapArray[i];
            heapArray[i] = temporary; 

            heapify(heapArray, i, 0); // recursion until heapify and sorting process is done.
        }
    }

	

	// Main method
	public static void main(String[] args) {
		// user interactive
		Scanner userInput = new Scanner (System.in);
		System.out.println("How big do you want the array to be?");
		final int arraySize = userInput.nextInt();
		int[] heapArray = new int[arraySize];

		for (int i = 0; i < arraySize; i++) {
			System.out.println("Enter array element #" + (i + 1));
			heapArray[i] = userInput.nextInt();
		}
		
		// sort the entered array
		heaperSorter(heapArray);

        System.out.println("Sorted array:");
        for (int i = 0; i < heapArray.length; i++) {
            System.out.print(heapArray[i] + " ");
        }

        userInput.close(); // avoiding resource leaks
	}
}
