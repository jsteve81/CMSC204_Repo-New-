import java.util.*;
import java.io.*;

public class RandomNumberGenerator
{
     public static void generateAndSaveNums() {
          Random randGen = new Random(); // random number Object
          
          try {
               // Binary and Text output objects
               DataOutputStream binaryOutput = new DataOutputStream(new FileOutputStream("nums.dat"));
               PrintWriter textOutput = new PrintWriter((new FileWriter("numbers.txt")));
               
               for (int i = 0; i < 50000; i++) {
                int value = randGen.nextInt(9000) + 1000; // generates from 1000-9999 randomly 50,000 times
                
                // write the random numbers to the binary and text files
                binaryOutput.writeInt(value);
                textOutput.println(value);
            }
                binaryOutput.close(); // closing to prevent resource leaking
		      textOutput.close();
          } catch (FileNotFoundException exception) { // catching and handling different exceptions
               System.out.println("The file(s) were not found.");
          } catch (IOException exception) {
               System.out.println("Error writing files.");
          } catch (Exception exception) {
               exception.getMessage();
          }
     }
     
     // method to read binary file
    public static void readBinary(String filename) {
        try (DataInputStream input = new DataInputStream(new FileInputStream(filename))) {

            int count = 0;

            for (int i = 0; i < 50000; i++) {
               int number = input.readInt();
               System.out.println(number);
            }

        } catch (FileNotFoundException exception) {
            System.out.println("The file(s) were not found.");
        } 
        catch (IOException exception) {
            System.out.println("Finished reading file.");
        } catch (Exception exception) {
            exception.getMessage();
        }
    }
     
     // main method
	public static void main(String[] args) {
		generateAndSaveNums(); // generate numbers
		readBinary("nums.dat"); // read binary file 
		
	}
}