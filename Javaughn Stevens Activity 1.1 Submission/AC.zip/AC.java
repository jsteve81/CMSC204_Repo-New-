public class AC {

	// for Bid interface
	private int unitCost;
	private int installCost;
	private String unitDescription;
	
	public AC() { // No-arg constructor
		
	}
	
	 public AC(int unitCost, int installCost, String unitDescription) { // Constructor with args
	        this.unitCost = unitCost;
	        this.installCost = installCost;
	        this.unitDescription = unitDescription;
	 }
	 
	 // Setters & Getters
	 public int getUnitCost() {
		 return unitCost;
	 }
	 
	 public void setUnitCost(int unitCost) {
		 this.unitCost = unitCost;
	 }
	 
	 public int getInstallCost() {
		 return installCost;
	 }
	 
	 public void setInstallCost(int installCost) {
		 this.installCost = installCost;
	 }
	 
	 public String getUnitDescription() {
		 return unitDescription;
	 }
	 
	 public void setUnitDescription (String unitDescription) {
		 this.unitDescription = unitDescription;
	 }
	
}
