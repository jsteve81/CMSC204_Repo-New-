/**
 * Name: Javaughn Stevens
 * M#: M21185543
 * Date: 1/30/26
 * The BidCollection ADT represents a collection of bids from companies
 * to install a specified air conditioning (AC) unit.
 * 
 * A bid consists of:
 *  - Company name
 *  - Unit description
 *  - Cost of the unit
 *  - Cost of installation
 */

public interface BidCollection {
	
	 boolean addBid(Bid bid);
	/**
	  * Purpose: Adds a Did object to the bid collection. 
	  @param The Bid object being added (Bid class must be implemented)
	  @return True or false whether or not the addition was successful.
	  */
	 
	  boolean cancelLastBid();
	  /**
	    * Purpose: Removes the most recently added Bid object from the Bid collection.
	    @param: None
	    @return True or false whether or not the cancellation was successful.
	    */
	  
	  
	  boolean cancelBid(Bid bid);
	  /**
	    * Purpose: Cancels a specific Bid object.
	    @param The Bid object being removed.
	    @return True or false whether or not the cancellation was successful.
	    */
	 
	  boolean cancelallBids();
	  /**
	    * Purpose: Cancels all the Bid objects in the bid collection. 
	    @param None
	    @return True or false whether or not the cancellation was successful.
	    */
	  
	  
	  int getSize();
	  /**
	    * Purpose: Tells the user the current number of Bid objects in the bid collection.
	    @param None (getter method)
	    @return the current number of Bid objects in the bid collection.
	    */
	  
	  
	  Bid[] toArray();
	  /**
	    * Purpose: Lists all the current existing Bid objects in the collection in an array.
	    @param None
	    @return an array of all the current existing Bid objects.
	    */
	 
	  boolean search(Bid bid);
	  /**
	    * Purpose: Searches the collection for a specified Bid object.
	    @param The Bid object being added (Bid class must be implemented)
	    @return True or false whether or not the Bid object exists in the collection.
	    */
	}