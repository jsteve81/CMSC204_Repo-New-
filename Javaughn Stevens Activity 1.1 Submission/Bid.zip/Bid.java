/**
 * Name: Javaughn Stevens
 * M#: M21185543
 * Date: 1/30/26
 * The Bid ADT represents a singular bid from a company
 * to install a specified air conditioning (AC) unit.
 * 
 * A bid consists of:
 *  - Company name
 *  - Unit description
 *  - Cost of the unit
 *  - Cost of installation
 * Note: I have implemented an AC class for AC objects to avoid compilation errors.
 */

public interface Bid {
	String getCompanyName(); 
	/**
     * Purpose: Returns the name of the company making the bid.
     @param None (getter method)
     @return Name of the company
     */
	
	void setCompanyName(String company);
	  /**
	   * Purpose: Selects a name for the biding company
	    @param String variable company 
	    @return None (void method)
	    */
	
	void placeBid(int price, AC ACunit);
	  /**
	    * Purpose: Places a bid for an air conditioner by a company. (Creates a bid object)
	    @param int variable price (price of the bid) and AC object ACUnit, and ACunit name of the AC unit being bided on.
	    @return None (void method) 
	    */
	
	String getACUnitDescription();
	/**
     * Purpose: Returns a description of the AC unit.
     @param None (getter method)
     @return Description of the AC unit
     */
	
	int getACUnitCost();
	/**
     * Purpose: Returns the cost of the AC unit in dollars as an integer.
     @param None (getter method)
     @return Cost of the AC unit
     */
	
	int getACInstallationCost();
	/**
     * Purpose: Returns the cost of installing the AC unit in dollars as an integer.
     @param None (getter method)
     @return Cost of installing the AC unit
     */
	
	boolean getBidStatus();
	/**
     * Purpose: Returns the status of a company's Bid object (win or lose)
     @param None (getter method)
     @return True or false (if the Bid object won or lost respectively)
     */
	

}
