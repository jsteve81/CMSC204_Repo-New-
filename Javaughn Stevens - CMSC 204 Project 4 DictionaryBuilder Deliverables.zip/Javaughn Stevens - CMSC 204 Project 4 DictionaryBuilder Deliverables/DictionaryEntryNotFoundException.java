import java.util.*;
import java.io.*;
// Javadoc comments
/**
 * The DictionaryEntryNotFoundException is a custom checked exception
 * that is thrown when an operation attempts to access or remove
 * a word that does not exist in the dictionary.
 * 
 * This exception is used to signal that a requested word could not be found.
 * 
 */

public class DictionaryEntryNotFoundException extends Exception {
	/**
	 * Constructs a new DictionaryEntryNotFoundException with a specified message.
	 *
	 * @param message the detail message explaining the reason for the exception
	 */

    public DictionaryEntryNotFoundException(String message) {
        super(message); // call to superclass
    }
}
