import java.util.*;
import java.io.*;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class MyLinkedListStudentTest {

	@BeforeAll
	static void setUpBeforeClass() throws Exception {
	}

	@AfterAll
	static void tearDownAfterClass() throws Exception {
	}

	@BeforeEach
	void setUp() throws Exception {
		MyLinkedList testList;
        testList = new MyLinkedList();
	}

	@AfterEach
	void tearDown() throws Exception {
		
	}

		// Testing every method and constructor 
		@Test
		void testNodeConstructor() {
			MyLinkedList testList;
	        testList = new MyLinkedList();
			testList.insertNode("car"); // creating a node
	        assertNotNull(testList.findNode("car")); // searching for the node
	        assertNull(testList.findNode("cAR"));

		}
		
		@Test
		void testFindNode() {
			MyLinkedList testList;
	        testList = new MyLinkedList();
			testList.insertNode("valley");
		    assertNotNull(testList.findNode("valley")); // searching for the node
		}
		
		@Test
		void testInsertNode() {
			MyLinkedList testList;
	        testList = new MyLinkedList();
			testList.insertNode("guitar");
	        assertEquals("guitar", testList.findNode("guitar").word); // these nodes are equal
	        assertNotEquals("guiTar!!", testList.findNode("guitar").word); // case sensitive
		}
		
		@Test
		void testDeleteNode() throws Exception {
			MyLinkedList testList;
	        testList = new MyLinkedList();
	        testList.insertNode("sweater"); // insert/add a node
	        testList.deleteNode("sweater");  // delete that node
	        assertNull(testList.findNode("sweater")); // node is now null
		}
		
		@Test
		void testGetWords() {
			MyLinkedList testList;
	        testList = new MyLinkedList();
			testList.insertNode("rope");
	        testList.insertNode("bird");
	        testList.insertNode("goat");
	        testList.insertNode("monkey"); // insert multiple nodes
	        assertEquals(4, testList.getWords().size());
		}
		
		@Test
		void testCollectWords() {
			MyLinkedList testList; // necessary for returning the ArrayList
	        testList = new MyLinkedList();
	        testList.insertNode("alpha");
	        testList.insertNode("beta");
	        testList.insertNode("theta");
	        List<String> testWordList = new ArrayList<>();
	        testList.collectWords(testWordList); // this runs the for loop in the implementation
	        assertEquals(3, testWordList.size());
		}
		
		// Edge cases
		
		// exception functionality
		@Test
		void testDictionaryEntryNotFoundException() {
			MyLinkedList testList; // necessary for returning the ArrayList
	        testList = new MyLinkedList();
			assertThrows(DictionaryEntryNotFoundException.class, () -> {
	            testList.deleteNode("mistake"); // node was never inserted, exception is thrown
	        });
		}
		
		@Test
		void testEmptyDictionaryException() {
			MyLinkedList testList; 
	        testList = new MyLinkedList();
			assertNull(testList.findNode("physics")); // word was never entered so it's null
		}
		
		
}
