// This is a basic implementation of a node-based graph. Nodes are also used in linked list and trees.

import java.util.*;
import java.io.*;

class SpecialNode { // We can create a node with whatever we want.
	String name;
	String color;
	int value;
	int distance = Integer.MAX_VALUE;

	// No arg constructor with no data. 
	public SpecialNode() {

	}
	
	// Constructor with args for giving a node data.
	public SpecialNode(String name, String color, int value) {
		this.name = name;
		this.color = color;
		this.value = value;
	}
	
	// Setters and Getters
	public void setName(String name) {
		this.name = name;
	}
	
	public void setColor(String color) {
		this.color = color;
	}
	
	public void setValue(int value) {
		this.value = value;
	}
	
	public String getName() {
		return name;
	}
	
	public String getColor() {
		return color;
	}
	
	public int getValue() {
		return value;
	}
	
	public String toString() {
		return ("Name: " + name + "\n Color: " + color + "\n Value: $" + value);
	}
}

/* Basically this is a version that mostly uses 203 concepts like constructors, setters, getters, toString.
 The only addition is the node object. */
