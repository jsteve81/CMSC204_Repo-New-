// This is a more advanced implementation of the node-based graph, using more 204 concepts such as hashmaps.

import java.util.*;
import java.io.*;

class SpecialNode2 {
	String name;
	String color;
	int value;
	int distance = Integer.MAX_VALUE;
	Map <SpecialNode2, Integer> hashNeighbor = new HashMap<>();
	// I wanted to implement a treeMap object but this is not aligned with the tutorial.
		
	List<SpecialNode2> fastestPath = new LinkedList<>(); // from tutorial
	// fastestPath is the same as "shortestPath"
	
	// No arg constructor with no data. 
	SpecialNode2() {

	}
		
	// Constructor with args for giving a node data.
	SpecialNode2(String name, String color, int value) {
		this.name = name;
		this.color = color;
		this.value = value;
	}
	
	// Add method
	void addSpecialNeighbor (SpecialNode2 node, int number) {
		// We can only have 2 parameters for maps
		hashNeighbor.put(node, number);
    }
	
	    // Setters and Getters
		public void setName(String name) {
			this.name = name;
		}
		
		public void setColor(String color) {
			this.color = color;
		}
		
		public void setValue(int value) {
			this.value = value;
		}
		
		public String getName() {
			return name;
		}
		
		public String getColor() {
			return color;
		}
		
		public int getValue() {
			return value;
		}
		
		public String toString() {
			return ("Name: " + name + "\n Color: " + color + "\n Value: $" + value);
		}
		
		// helper methods to avoid hashMap/hashSet bugs
		@Override
		public boolean equals(Object object) {
		    if (this == object) { // if the object references itself, they are equal.
		    	return true;
		    }
		    if ((object instanceof SpecialNode2) == false) { // if the object is not an instance, they are not equal.
		    	return false;
		    }
		    SpecialNode2 node = (SpecialNode2) object; // type casting
		    if (Objects.equals(name, node.name) == true) { // Java import/collections class
		    	return true;
		    } else {
		    	return false;
		    }
		}

		@Override
		public int hashCode() {
			int result = 17;
			if (name == null) {
				result = (31 * result) + 0; // no name
			} else {
				result = (31 * result) + name.hashCode(); // name has a hash code
			}
		    return result;
		}
}