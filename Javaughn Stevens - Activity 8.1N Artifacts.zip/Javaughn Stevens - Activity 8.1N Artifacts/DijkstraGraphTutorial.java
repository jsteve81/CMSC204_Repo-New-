import java.util.*;
import java.io.*;

// guided from tutorial

public class DijkstraGraphTutorial {
	public static void calculateFastestPath(SpecialNode2 node) {
		node.distance = 0;

		// hashsets containing SpecialNode2 objects
	    Set<SpecialNode2> settledNodes = new HashSet<>(); // nodes where shortest/fastest path has been determined
	    Set<SpecialNode2> unsettledNodes = new HashSet<>(); // nodes where shortest/fastest path has not been determined

	    unsettledNodes.add(node);

	    // if the unsettled nodes
	    while (unsettledNodes.isEmpty() == false) {
	        SpecialNode2 currentNode = getLowestDistanceNode(unsettledNodes);
	        unsettledNodes.remove(currentNode);

	        // for each loop
	        for (Map.Entry<SpecialNode2, Integer> pair : currentNode.hashNeighbor.entrySet()) {
	            SpecialNode2 adjacentNode = pair.getKey();
	            int edgeWeight = pair.getValue(); // Map hashNeighbor uses (K,V) or (Key, Value)

	            if (settledNodes.contains(adjacentNode) == false) {
	                calculateMinimumDistance(adjacentNode, edgeWeight, currentNode);
	                unsettledNodes.add(adjacentNode);
	            }
	        }

	        settledNodes.add(currentNode);
	    }
	}
	
	
	// helper method #1 from tutorial
	private static SpecialNode2 getLowestDistanceNode(Set<SpecialNode2> nodeSet) {
        SpecialNode2 lowestNode = null;
        int lowestDistance = Integer.MAX_VALUE;

        // for each loop for sets
        for (SpecialNode2 node : nodeSet) {
            if (node.distance < lowestDistance) {
                lowestDistance = node.distance;
                lowestNode = node; // similar to finding the minimum element of an array
            }
        }
        return lowestNode;
    }
	
	// helper method #2 from tutorial
	private static void calculateMinimumDistance(SpecialNode2 evalNode, int edgeWeight, SpecialNode2 sourceNode) {

    int sourceDistance = sourceNode.distance;    
        if ((sourceDistance + edgeWeight) < evalNode.distance) {
        	evalNode.distance = sourceDistance + edgeWeight;

        	LinkedList<SpecialNode2> fastestPath = new LinkedList<>(sourceNode.fastestPath);
            fastestPath.add(sourceNode);
            evalNode.fastestPath = fastestPath;
            }
		}
	}
