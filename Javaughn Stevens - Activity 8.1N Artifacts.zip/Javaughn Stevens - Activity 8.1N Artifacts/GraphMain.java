// Main method for testing the node/graph classes
import java.util.*;
import java.io.*;

public class GraphMain {
	public static void main(String[] args) {
		System.out.println("SpecialNode Test..."); // testing basic 203 implementation
		// creating nodes...
		SpecialNode testNode1 = new SpecialNode("MyGraph", "Blue", 50);
		SpecialNode testNode2 = new SpecialNode("MyGraph2", "Red", 45);
		SpecialNode testNode3 = copySpecialNode(testNode2);
		
		System.out.println(testNode1);
		System.out.println(""); // output formatting
		System.out.println(testNode2); 
		System.out.println(""); 
		System.out.println(testNode3); // print out the nodes
		
		
		System.out.println(""); 
		System.out.println(""); 
		System.out.println("SpecialNode2 Test..."); // testing advanced implementation
		
		// creating nodes...
		SpecialNode2 testNodeA = new SpecialNode2("New Graph", "Purple", 250);
		SpecialNode2 testNodeB = new SpecialNode2("Math Graph", "Silver", 1000);
		SpecialNode2 testNodeC = copySpecialNode2(testNodeB);
		
		System.out.println(testNodeA);
		System.out.println(""); 
		System.out.println(testNodeB); 
		System.out.println(""); 
		System.out.println(testNodeC); // print out the nodes
		
		testNodeA.addSpecialNeighbor(testNodeB, testNodeB.getValue());
		testNodeA.addSpecialNeighbor(testNodeC, testNodeC.getValue());
		
		System.out.println(""); 
		System.out.println(""); 
		System.out.println(""); 
		System.out.println("");  // more formatting
		System.out.println("Dijkstra Algorithm Integration: "); 
		
		// creating nodes
		SpecialNode2 integrated1 = new SpecialNode2("MATLAB1", "Red", 150);
		SpecialNode2 integrated2 = new SpecialNode2("MATLAB2", "Blue", 600);
		SpecialNode2 integrated3 = new SpecialNode2("MATLAB3", "Green", 300);
		SpecialNode2 integrated4 = new SpecialNode2("MATLAB4", "Yellow", 875);

		// connect the nodes to make a graph using the neighbor hashMap
		integrated1.addSpecialNeighbor(integrated2, 10);
		integrated1.addSpecialNeighbor(integrated3, 35);
		integrated2.addSpecialNeighbor(integrated4, 22);
		integrated3.addSpecialNeighbor(integrated4, 60);
		integrated2.addSpecialNeighbor(integrated1, 40);

		// run the Dijkstra algorithm class to calculate the shortest/fastest paths
		integrated1.distance = Integer.MAX_VALUE;
		integrated2.distance = Integer.MAX_VALUE;
		integrated3.distance = Integer.MAX_VALUE;
		integrated4.distance = Integer.MAX_VALUE; // reset distances
		DijkstraGraphTutorial.calculateFastestPath(integrated1);



		for (SpecialNode2 node : Arrays.asList(integrated1, integrated2, integrated3, integrated4)) {
			System.out.println("Node: " + node.getName());
			System.out.println("Distance: " + node.distance);
			System.out.print("Path: ");
			
		    for (SpecialNode2 pathNode : node.fastestPath) {
		        System.out.print(pathNode.getName() + " -> ");
		    }
		    System.out.println(node.getName());
			System.out.println(""); 
		}

		
	}
	
    // copy a node
	public static SpecialNode copySpecialNode(SpecialNode node) {			
		// call constructor with the original nodes data
		SpecialNode copyNode = new SpecialNode(node.getName() + ".copy", node.getColor(), node.getValue());
		return copyNode;
	}
	
	public static SpecialNode2 copySpecialNode2(SpecialNode2 node) {			
		// call constructor with the original nodes data
		SpecialNode2 copyNode = new SpecialNode2(node.getName() + ".copy", node.getColor(), node.getValue());
		return copyNode;
	}
	
	
	
}
