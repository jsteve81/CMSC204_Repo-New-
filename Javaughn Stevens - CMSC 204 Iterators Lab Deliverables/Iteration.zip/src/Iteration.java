import java.util.*;
import java.io.*;

public class Iteration {

	public static void main(String[] args) {
		ArrayList<Integer> intList = new ArrayList<>(); // Setting up ArrayList, Random, and Iterator objects
		Random randomNumber = new Random();
		ListIterator<Integer> intIterator;
		
		int minBound = 10;
		int maxBound = 99; // setting up the range for random number generation
		int count = 10;
		
		for (int i = 0; i < count; i++) {
            int random = randomNumber.nextInt(maxBound - minBound + 1) + minBound;
            						// (99 - 10 + 1) + 10

            intList.add(random);
        } // this for loop creates 10 integers from 10-99 and adds them one by one into the ArrayList object.
		
		System.out.print("Your game begins with the following 10 elements: ");
		
		for (int a = 0; a < intList.size(); a++) {
            System.out.print(intList.get(a) + " "); // prints all the elements
        }
		
		System.out.println(""); // for spacing.
		
		int iterationCounter = 0;
		for (int b = 0; b < intList.size(); b++) {
			iterationCounter++;	// counting the # of iterations
			System.out.println("");
			System.out.println("Starting iteration #" + iterationCounter +" at index " + b); // start at each interation from 0.			
			intIterator = intList.listIterator(b);
			
			while (intIterator.hasNext() == true) { // while there is another element to iterate.
				if (intIterator.hasNext() == false) {
					break; // leave the while loop if we reach the last element
				}
				int value1 = intIterator.next();
				
				int value2 = intIterator.next(); 
				// we can have the same assignment statement because intIterator.next() changes with every call
				
				// Digit separation of integer variables, I recently learned this in ENEE 140
				int firstDigit1 = value1 / 10; // e.g 46 / 10 = 4
				int secondDigit1 = value1 % 10; // 46 % 10 = 6
				
				int firstDigit2 = value2 / 10;
				int secondDigit2 = value2 % 10;
				
				if (firstDigit1 == firstDigit2 || secondDigit1 == secondDigit2) {

					System.out.println("Match found: " + value1 + " and " + value2);
					System.out.println("Reason: First or second digits are a match.");
					
					// we remove the two matching elements from the arrayList
					intList.remove(b + 1);
					intList.remove(b);

					System.out.print("List after removal: ");
					for (int a = 0; a < intList.size(); a++) {
			            System.out.print(intList.get(a) + " "); // prints all the elements
			        }
					System.out.println("");
					break;
				} else {
					System.out.println("No removal could be made for this iteration.");
					// lets the user know the current list was unchanged.
					break;
				}
				
			}
			
		}
		
		System.out.println("");
		System.out.print("Final list after all removals: ");
		for (int a = 0; a < intList.size(); a++) {
            System.out.print(intList.get(a) + " "); // prints all the elements
        }
		
	}

}
